import { SafeAreaView, View, Text, Image, StyleSheet, TextInput, Button} from 'react-native';

import {useState} from 'react'

function AppMyPerfil(){ 
  const [aleatorio, setAleatorio] = useState('');
  let img = 'https://pm1.aminoapps.com/6566/0791f432a62d358fc985c5ba413f8b7638609383_00.jpg';
  function tarcisio(){
    setAleatorio(Math.floor(Math.random() * 11))
  }
  return(
    <View>
      <Text style={{color: '#0d0d0d', fontSize: 20, textAlign: 'center', padding: '20px'}}>
        Número aleatório
      </Text>

      <Image
        source={{uri: img}}
        style={{width: 200, height: 200, margin: 'auto'}}
      />
      <Text style={{textAlign: 'center'}}>Pense em um número de 0 a 10</Text>
      <Text style={styles.texto}> {aleatorio} </Text>
      <Button style={{padding: 10}} title="Verificar" onPress={tarcisio} />
    </View>
    // JSX é a programação em react native (JS com XML)
  )
}

const styles = StyleSheet.create({
  texto:{
    color: '#0d0d0d',
    fontSize: 20,
    textAlign: 'center',
    padding: '20px'
  }
})

export default AppMyPerfil;
